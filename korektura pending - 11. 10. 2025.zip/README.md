# OmoriCZ
Český překlad pro hru OMORI
